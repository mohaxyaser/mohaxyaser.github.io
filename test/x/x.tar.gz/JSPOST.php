<!--{"AntiBan":"","Stop":"","StopMsg":"","Update":"","UpdateMsg":""}-->

{
	  "status" : "ok",
	  "message" : "Code error, please use the correct code or buy a new one"
	}
