<?php


error_reporting(0);

$myObj->SiteUrl = "https://www.kindpng.com/picc/m/200-2006734_safe-clipart-transparent-not-safe-clipart-png-png.png";
$myObj->JASEM = "2SAiF";
$myObj->Update = "5";
$myObj->Close = "NO";
$myJSON = json_encode($myObj);
echo  $myJSON;

?>


<!--{-->
<!--  "SiteUrl" : "https://www.kindpng.com/picc/m/200-2006734_safe-clipart-transparent-not-safe-clipart-png-png.png",-->
<!--  "JASEM" : "2SAiF",-->
<!--  "Update" : "5",-->
<!--  "Close" : "NO"-->
<!--}-->